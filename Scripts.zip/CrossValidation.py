import os, shutil, os.path

# Dividir un array
def split_list(alist, wanted_parts):
    
    length = len(alist)
    return [ alist[i*length // wanted_parts: (i+1)*length // wanted_parts] 
             for i in range(wanted_parts) ]


def deleteFolders(path):
    
    # Eliminamos El contenido de la carpeta
    for the_file in os.listdir(path):
        file_path = os.path.join(path, the_file)
        
        try:
            if os.path.isfile(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path): 
                shutil.rmtree(file_path)
                
        except Exception as e:
            print(e)
            
            
def createFolders(path):
    newpath=os.path.join(os.sep, path, "train_image_folder")
    if not os.path.exists(newpath):
        os.makedirs(newpath)
        
    newpath=os.path.join(os.sep, path, "train_annot_folder")
    if not os.path.exists(newpath):
        os.makedirs(newpath)
        
    newpath=os.path.join(os.sep, path, "valid_image_folder")
    if not os.path.exists(newpath):
        os.makedirs(newpath)
        
    newpath=os.path.join(os.sep, path, "valid_annot_folder")
    if not os.path.exists(newpath):
        os.makedirs(newpath)
        
        
        
def moveFiles(path, pathOriginalImages, pathOriginalAnnots, groups, i):
        
    for imagesFile in groups[i]:
        newpath=os.path.join(os.sep, pathOriginalImages, imagesFile)
        shutil.copy(newpath, os.path.join(os.sep, path, "valid_image_folder"))
        imagesFile=imagesFile.replace(".jpg",".xml")
        newpath=os.path.join(os.sep, pathOriginalAnnots, imagesFile)
        shutil.copy(newpath, os.path.join(os.sep, path, "valid_annot_folder"))
            
    
    for tupla in groups:
        for imagesFile in tupla:
            if not imagesFile in groups[i]:
                newpath=os.path.join(os.sep, pathOriginalImages, imagesFile)
                shutil.copy(newpath, os.path.join(os.sep, path, "train_image_folder"))
                imagesFile=imagesFile.replace(".jpg",".xml")
                newpath=os.path.join(os.sep, pathOriginalAnnots, imagesFile)
                shutil.copy(newpath, os.path.join(os.sep, path, "train_annot_folder"))
            

def crossValidation(path, pathOriginalImages, pathOriginalAnnots, k, i):
               
    # Número de imagenes en la carpeta original
    numberOfImages=len([name for name in os.listdir(pathOriginalImages) if os.path.isfile(os.path.join(pathOriginalImages, name))])
    
    if not numberOfImages%k==0:
        print("El número de imagenes tiene que ser divisible por la variable 'k'")
        print("el número de imagenes es de: "+str(numberOfImages))
        
    else:
             
        # Creamos una lista con los nombres de los archivos
        nameOfFiles=[]
        
        for file in os.listdir(pathOriginalImages):
            nameOfFiles.append(file)
        
        # Los separamos ppor grupos
        groups=split_list(nameOfFiles, k)
        
        # Aliminamos el contenido de la carpeta
        deleteFolders(path)
        
        # Creamos las carpetas
        createFolders(path)
           
        #Distribuimos las imagenes
        moveFiles(path, pathOriginalImages, pathOriginalAnnots, groups, i)