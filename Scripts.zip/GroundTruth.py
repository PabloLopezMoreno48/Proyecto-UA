import os
import linecache
import re

def groundTruth(pathOfAnnots):
    
    groundTruthDictionary=dict()
    
    for file in (os.listdir(pathOfAnnots)):
        
        num_lines = sum(1 for line in open(os.path.join(pathOfAnnots, file)))
        bbox_xml=[]
        
        # Recogemos el bbox del xml
        for i in range(num_lines+1): 
            line = linecache.getline(os.path.join(pathOfAnnots, file), i)
            if "xmin" in line:
                bbox_xml.append(int(re.search("(>)([0-9](.*))(<)",line).group(2)))
            if "ymin" in line:
                bbox_xml.append(int(re.search("(>)([0-9](.*))(<)",line).group(2)))
            if "xmax" in line:
                bbox_xml.append(int(re.search("(>)([0-9](.*))(<)",line).group(2)))
            if "ymax" in line:
                bbox_xml.append(int(re.search("(>)([0-9](.*))(<)",line).group(2)))
                
        key=file.replace(".xml",".jpg")
        groundTruthDictionary[key]=bbox_xml       
        
    
    return groundTruthDictionary