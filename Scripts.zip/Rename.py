import os
import re


def rename(formato,style, path):
    formatName=re.search("(.*)(_)(.*)",style).group(1)
       
    i=0 # CMABIAR
    for file in os.listdir(path):
        
        if i<10:
            number="0000%s" % (i)
        elif i<100:
            number="000%s" % (i)
        elif i<1000:
            number="00%s" % (i)
        else:
            number="0%s" % (i)
            
        name=formatName+"_"+str(number)+formato # CAMBIAR
        os.rename(os.path.join(path, file), os.path.join(path, name))
        i+=1