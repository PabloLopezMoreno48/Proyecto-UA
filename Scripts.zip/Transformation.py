from PIL import Image, ImageOps
import os
import numpy as np
import random
import cv2
from resized import resize_image
from skimage import io
from skimage import transform as tf

def mirror(pathImages):
    
    numberOfImages=len([name for name in os.listdir(pathImages) if os.path.isfile(os.path.join(pathImages, name))])
    
    # Imagenes
    for img in (os.listdir(pathImages)):

        imagen=Image.open(os.path.join(pathImages, img))
        espejo = ImageOps.mirror(imagen)
        espejo.save(os.path.join(pathImages, 'test_{:05}.jpg'.format(numberOfImages)))
        numberOfImages+=1
        width, height = imagen.size
        

def noisy(path):
    aux=0
    for file in os.listdir(path):
        print(file)
        image = cv2.imread (os.path.join(path,file),1)
        row,col,ch = image.shape
        s_vs_p = 0.8
        amount = 0.004
        out = np.copy(image)
    
        num_salt = np.ceil(amount * image.size * s_vs_p)
        coords = [np.random.randint(0, i - 1, int(num_salt)) for i in image.shape]
        out[coords] = 1
        # Pepper mode
        num_pepper = np.ceil(amount* image.size * (1. - s_vs_p))
        coords = [np.random.randint(0, i - 1, int(num_pepper)) for i in image.shape]
        out[coords] = 0
        cv2.imwrite(os.path.join(path, 'test_{:05}.jpg'.format(aux)), out)
        aux+=1
        

def crop(image_path, coords):
    
    numberOfImages=len([name for name in os.listdir(pathImages) if os.path.isfile(os.path.join(pathImages, name))])
    
    for img in (os.listdir(image_path)):
        
        image = Image.open(os.path.join(pathImages, img))
        w, h = image.size

        cropped_image = image.crop(coords)
        
        resized_image = cropped_image.resize((w,h))

        resized_image.save(os.path.join(image_path, 'test_{:05}.jpg'.format(numberOfImages)))
        numberOfImages+=1
        
def shear(pathImages):
    
    numberOfImages=len([name for name in os.listdir(pathImages) if os.path.isfile(os.path.join(pathImages, name))])
    
    for img in (os.listdir(pathImages)):
        
        image = io.imread(os.path.join(pathImages, img))
        afine_tf = tf.AffineTransform(shear=0.2)
        modified = tf.warp(image, inverse_map=afine_tf)
        
        io.imsave(os.path.join(pathImages, 'test_{:05}.jpg'.format(numberOfImages)),modified)
        numberOfImages+=1