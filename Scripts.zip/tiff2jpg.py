from PIL import Image
import os

def tiffToJPG(path):
    n = 0
    for img in (os.listdir(path)):
        im = Image.open(os.path.join(path, img))
        im= im.save(os.path.join(path_folder, 'testing_{:05}.jpg'.format(n)))
        n+=1