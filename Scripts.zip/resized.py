from PIL import Image
import os
 
def resize_image(pathOriginal, pathNewFolder, w, h):
    
    for img in (os.listdir(pathOriginal)):
        
        original_image = Image.open(os.path.join(pathOriginal, img))
        resized_image = original_image.resize((w,h))
        resized_image.save(os.path.join(pathNewFolder, img))