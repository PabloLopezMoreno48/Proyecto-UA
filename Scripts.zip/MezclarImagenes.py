import os
import re
import random
import string
from Rename import rename

def randomName():
    
    chars = string.ascii_uppercase + string.ascii_lowercase + string.digits
    size = random.randint(6, 12)
    return ''.join(random.choice(chars) for x in range(size))



def mezclar(pathImages, pathAnnots):
    
    for file in os.listdir(pathImages):
        style=file
        name=randomName()
        os.rename(os.path.join(pathImages, style), os.path.join(pathImages, name+".jpg"))
        style=style.replace(".jpg", ".xml")
        os.rename(os.path.join(pathAnnots, style), os.path.join(pathAnnots, name+".xml"))
        
    style.replace(".jpg","")  
    
    formato=".jpg"
    rename(formato,style , pathImages)
    
    formato=".xml"
    rename(formato,style , pathAnnots)