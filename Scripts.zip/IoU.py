from GroundTruth import groundTruth
import shapely
from shapely.geometry import Polygon


def IoU_calculator(bbox,bbox_aux):
    area_of_intersection = int((bbox.intersection(bbox_aux)).area)
    area_of_union=int((bbox.union(bbox_aux)).area)
    IoU=area_of_intersection/area_of_union
    return IoU



def IoUs_perImage(detectedPeopleDict, pathOfAnnots):
    groundTruthDictionary=groundTruth(pathOfAnnots)
    IoUDictionay=dict()
    
    totalPeople=0
    for key, value in detectedPeopleDict.items():
        peopleDetected=len(value)
        bboxesPerImage=groundTruthDictionary[key]
        peoplePerImage=int(len(bboxesPerImage)/4)
        
        IoU=[]
        for i in range(peopleDetected):
            # Cogemos los ground truth por orden para analizar
            bboxDetected=shapely.geometry.box(value[i][0],value[i][1],value[i][2],value[i][3])
            
            IoUValueAux=0
            for x in range(peoplePerImage):
                
                auxX=x*4
                bboxPrior=shapely.geometry.box(bboxesPerImage[auxX],bboxesPerImage[auxX+1],bboxesPerImage[auxX+2],bboxesPerImage[auxX+3])
                
                # Si intersecta lo analizamos para calcular el IoU
                if bboxDetected.intersects(bboxPrior):
                    IoUValue=round(IoU_calculator(bboxDetected,bboxPrior),2)
                
                if IoUValue>IoUValueAux:
                    IoUValueAux=IoUValue
                    
        
            if IoUValueAux>0.5:
                IoU.append(IoUValueAux)
                
        totalPeople=totalPeople+peoplePerImage
        auxDict=[]
        auxDict.append([peoplePerImage])
        auxDict.append(IoU)
        IoUDictionay[key]=auxDict

    IoUDictionay["totalPeople"]=totalPeople
    
    return IoUDictionay